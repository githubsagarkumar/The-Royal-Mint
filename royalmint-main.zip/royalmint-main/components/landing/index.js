import Landing from "./landing";

export default Landing;
